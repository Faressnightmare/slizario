export interface Point {
  x: number;
  y: number;
}

export interface Snake {
  id: string;
  isPlayer: boolean;
  name: string;
  segments: Point[];
  color: string;
  radius: number;
  targetLength: number;
  angle: number;
  targetAngle: number;
  speed: number;
  baseSpeed: number;
  boostSpeed: number;
  isBoosting: boolean;
  score: number;
  dead: boolean;
  turnSpeed: number;
  botTarget?: Point | null;
  botStateTimer?: number;
}

export interface Food {
  id: string;
  x: number;
  y: number;
  color: string;
  value: number;
  size: number;
}

export interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  maxLife: number;
  color: string;
  size: number;
}

export interface GameState {
  worldWidth: number;
  worldHeight: number;
  snakes: Snake[];
  foods: Food[];
  particles: Particle[];
}
