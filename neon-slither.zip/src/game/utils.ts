import { Point } from './types';

export const distance = (p1: Point, p2: Point) => {
  const dx = p1.x - p2.x;
  const dy = p1.y - p2.y;
  return Math.sqrt(dx * dx + dy * dy);
};

export const lerp = (start: number, end: number, t: number) => {
  return start + (end - start) * t;
};

export const lerpAngle = (a: number, b: number, t: number) => {
  const d = b - a;
  let delta = d % (Math.PI * 2);
  if (delta > Math.PI) delta -= Math.PI * 2;
  else if (delta < -Math.PI) delta += Math.PI * 2;
  return a + delta * t;
};

export const randomColor = () => {
  const hue = Math.floor(Math.random() * 360);
  return `hsl(${hue}, 100%, 60%)`;
};
