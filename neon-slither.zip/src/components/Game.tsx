import React, { useEffect, useRef, useState } from 'react';
import { GameRenderer } from '../client/GameRenderer';
import { Trophy, Zap } from 'lucide-react';
import { io, Socket } from 'socket.io-client';
import { GameState } from '../game/types';

interface GameProps {
  playerName: string;
  onGameOver: (score: number) => void;
}

export const Game: React.FC<GameProps> = ({ playerName, onGameOver }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [score, setScore] = useState(0);
  const [leaderboard, setLeaderboard] = useState<{name: string, score: number}[]>([]);
  const socketRef = useRef<Socket | null>(null);
  const stateRef = useRef<GameState | null>(null);
  const rendererRef = useRef<GameRenderer | null>(null);
  const mouseRef = useRef({ x: 0, y: 0, isDown: false });
  const playerIdRef = useRef<string | null>(null);
  const isDeadRef = useRef(false);
  const scoreRef = useRef(0);
  const onGameOverRef = useRef(onGameOver);

  useEffect(() => {
    onGameOverRef.current = onGameOver;
  }, [onGameOver]);

  useEffect(() => {
    if (!canvasRef.current) return;
    const canvas = canvasRef.current;
    
    const handleResize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };
    handleResize();
    window.addEventListener('resize', handleResize);

    rendererRef.current = new GameRenderer(canvas);
    
    // Connect to the same host
    const socket = io();
    socketRef.current = socket;

    socket.emit('join', playerName);

    socket.on('joined', (id: string) => {
      playerIdRef.current = id;
    });

    socket.on('snakeDied', (data: { x: number, y: number, color: string }) => {
      if (rendererRef.current) {
        rendererRef.current.addParticles(data.x, data.y, data.color, 40);
      }
    });

    socket.on('state', (newState: GameState) => {
      stateRef.current = newState;
      
      if (playerIdRef.current) {
        const me = newState.snakes.find(s => s.id === playerIdRef.current);
        if (me) {
          const currentScore = Math.floor(me.score);
          setScore(currentScore);
          scoreRef.current = currentScore;
        } else if (!isDeadRef.current) {
          isDeadRef.current = true;
          onGameOverRef.current(scoreRef.current);
        }
      }

      // Update leaderboard
      const newLeaderboard = newState.snakes
        .map(s => ({ name: s.name, score: Math.floor(s.score) }))
        .sort((a, b) => b.score - a.score)
        .slice(0, 10);
      setLeaderboard(newLeaderboard);
    });

    // Input handling
    const updateInput = () => {
      if (!socketRef.current || !playerIdRef.current || !rendererRef.current) return;
      
      const screenCenterX = canvas.width / 2;
      const screenCenterY = canvas.height / 2;
      const targetAngle = Math.atan2(mouseRef.current.y - screenCenterY, mouseRef.current.x - screenCenterX);
      
      socketRef.current.emit('input', {
        targetAngle,
        isBoosting: mouseRef.current.isDown
      });
    };

    const inputInterval = setInterval(updateInput, 1000 / 30); // Send input at 30fps

    const handleMouseMove = (e: MouseEvent) => {
      mouseRef.current.x = e.clientX;
      mouseRef.current.y = e.clientY;
    };
    const handleMouseDown = () => { mouseRef.current.isDown = true; };
    const handleMouseUp = () => { mouseRef.current.isDown = false; };
    
    const handleTouchMove = (e: TouchEvent) => {
      e.preventDefault();
      mouseRef.current.x = e.touches[0].clientX;
      mouseRef.current.y = e.touches[0].clientY;
    };
    const handleTouchStart = (e: TouchEvent) => {
      handleTouchMove(e);
      mouseRef.current.isDown = true;
    };
    const handleTouchEnd = () => { mouseRef.current.isDown = false; };

    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mousedown', handleMouseDown);
    window.addEventListener('mouseup', handleMouseUp);
    canvas.addEventListener('touchmove', handleTouchMove, { passive: false });
    canvas.addEventListener('touchstart', handleTouchStart, { passive: false });
    canvas.addEventListener('touchend', handleTouchEnd);

    // Render loop
    let animationFrameId: number;
    const render = () => {
      if (stateRef.current && rendererRef.current) {
        rendererRef.current.draw(stateRef.current, playerIdRef.current);
      }
      animationFrameId = requestAnimationFrame(render);
    };
    render();

    return () => {
      window.removeEventListener('resize', handleResize);
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mousedown', handleMouseDown);
      window.removeEventListener('mouseup', handleMouseUp);
      canvas.removeEventListener('touchmove', handleTouchMove);
      canvas.removeEventListener('touchstart', handleTouchStart);
      canvas.removeEventListener('touchend', handleTouchEnd);
      
      clearInterval(inputInterval);
      cancelAnimationFrame(animationFrameId);
      socket.disconnect();
    };
  }, [playerName]);

  return (
    <div className="relative w-full h-screen overflow-hidden bg-slate-950">
      <canvas 
        ref={canvasRef} 
        className="block w-full h-full cursor-crosshair"
      />
      
      {/* UI Overlay */}
      <div className="absolute top-4 left-4 pointer-events-none">
        <div className="bg-slate-900/80 backdrop-blur-md border border-slate-800 rounded-2xl p-4 shadow-xl flex items-center gap-3">
          <div className="bg-emerald-500/20 p-2 rounded-xl">
            <Trophy className="w-6 h-6 text-emerald-400" />
          </div>
          <div>
            <p className="text-slate-400 text-xs font-semibold uppercase tracking-wider">Your Score</p>
            <p className="text-white text-2xl font-bold font-mono">{score}</p>
          </div>
        </div>
      </div>

      <div className="absolute top-4 right-4 pointer-events-none">
        <div className="bg-slate-900/80 backdrop-blur-md border border-slate-800 rounded-2xl p-4 shadow-xl w-64">
          <h3 className="text-slate-300 text-sm font-bold uppercase tracking-wider mb-3 flex items-center gap-2">
            <Trophy className="w-4 h-4 text-amber-400" /> Leaderboard
          </h3>
          <div className="space-y-2">
            {leaderboard.map((entry, idx) => (
              <div key={idx} className={`flex justify-between items-center text-sm ${entry.name === playerName ? 'text-emerald-400 font-bold' : 'text-slate-300'}`}>
                <span className="flex items-center gap-2">
                  <span className="text-slate-500 w-4">{idx + 1}.</span>
                  <span className="truncate max-w-[120px]">{entry.name}</span>
                </span>
                <span className="font-mono">{entry.score}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 pointer-events-none text-center">
        <div className="bg-slate-900/80 backdrop-blur-md border border-slate-800 rounded-full px-6 py-3 shadow-xl inline-flex items-center gap-3">
          <Zap className="w-5 h-5 text-amber-400 animate-pulse" />
          <span className="text-slate-300 font-medium">Click or Touch to Boost</span>
        </div>
      </div>
    </div>
  );
};
