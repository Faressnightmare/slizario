import { Server, Socket } from 'socket.io';
import { GameState, Snake, Food, Point } from '../game/types';
import { distance, lerpAngle, randomColor } from '../game/utils';

const WORLD_SIZE = 3000;
const INITIAL_FOOD_COUNT = 300;
const BOT_COUNT = 10;
const BASE_SNAKE_RADIUS = 12;
const BASE_SPEED = 2.5;
const BOOST_SPEED = 5.5;
const TURN_SPEED = 0.06;

const BOT_NAMES = ['Shadow', 'Viper', 'Neon', 'Ghost', 'Titan', 'Apex', 'Venom', 'Cobalt', 'Nova', 'Pulse'];

export class GameRoom {
  public state: GameState;
  private io: Server;
  private lastTime: number = 0;
  private loopInterval: NodeJS.Timeout | null = null;

  constructor(io: Server) {
    this.io = io;
    this.state = {
      worldWidth: WORLD_SIZE,
      worldHeight: WORLD_SIZE,
      snakes: [],
      foods: [],
      particles: [] // Kept for type compatibility, but unused on server
    };

    this.initGame();
    this.setupSockets();
  }

  private initGame() {
    for (let i = 0; i < BOT_COUNT; i++) {
      this.addBot();
    }
    for (let i = 0; i < INITIAL_FOOD_COUNT; i++) {
      this.addFood();
    }
  }

  public start() {
    this.lastTime = Date.now();
    this.loopInterval = setInterval(() => {
      const now = Date.now();
      const dt = (now - this.lastTime) / (1000 / 30);
      this.lastTime = now;
      this.update(dt);
      
      const stateToSend = {
        worldWidth: this.state.worldWidth,
        worldHeight: this.state.worldHeight,
        snakes: this.state.snakes.map(s => ({
          id: s.id,
          name: s.name,
          color: s.color,
          radius: Math.round(s.radius),
          score: Math.round(s.score),
          isBoosting: s.isBoosting,
          dead: s.dead,
          angle: s.angle,
          segments: s.segments.map(seg => ({ x: Math.round(seg.x), y: Math.round(seg.y) }))
        })),
        foods: this.state.foods.map(f => ({
          id: f.id,
          x: Math.round(f.x),
          y: Math.round(f.y),
          size: Math.round(f.size),
          color: f.color,
          value: f.value
        })),
        particles: []
      };
      
      this.io.volatile.emit('state', stateToSend);
    }, 1000 / 30); // 30 FPS server tick
  }

  private setupSockets() {
    this.io.on('connection', (socket) => {
      socket.on('join', (name: string) => {
        const x = Math.random() * WORLD_SIZE;
        const y = Math.random() * WORLD_SIZE;
        const snake = this.createSnake(socket.id, true, name || 'Player', x, y);
        
        // Remove old snake if exists
        this.state.snakes = this.state.snakes.filter(s => s.id !== socket.id);
        this.state.snakes.push(snake);
        
        socket.emit('joined', socket.id);
      });

      socket.on('input', (data: { targetAngle: number, isBoosting: boolean }) => {
        const snake = this.state.snakes.find(s => s.id === socket.id);
        if (snake && !snake.dead) {
          snake.targetAngle = data.targetAngle;
          snake.isBoosting = data.isBoosting;
        }
      });

      socket.on('disconnect', () => {
        const snake = this.state.snakes.find(s => s.id === socket.id);
        if (snake) {
          snake.dead = true;
          this.handleSnakeDeath(snake);
        }
      });
    });
  }

  private createSnake(id: string, isPlayer: boolean, name: string, x: number, y: number): Snake {
    const initialLength = 40;
    const segments: Point[] = [];
    for (let i = 0; i < initialLength; i++) {
      segments.push({ x, y: y + i * 3 });
    }

    return {
      id,
      isPlayer,
      name,
      segments,
      color: randomColor(),
      radius: BASE_SNAKE_RADIUS,
      targetLength: initialLength,
      angle: -Math.PI / 2,
      targetAngle: -Math.PI / 2,
      speed: BASE_SPEED,
      baseSpeed: BASE_SPEED,
      boostSpeed: BOOST_SPEED,
      isBoosting: false,
      score: 10,
      dead: false,
      turnSpeed: TURN_SPEED
    };
  }

  private addBot() {
    const x = Math.random() * WORLD_SIZE;
    const y = Math.random() * WORLD_SIZE;
    const name = `${BOT_NAMES[Math.floor(Math.random() * BOT_NAMES.length)]} (bot)`;
    this.state.snakes.push(this.createSnake(`bot_${Math.random()}`, false, name, x, y));
  }

  private addFood(x?: number, y?: number, value?: number, color?: string) {
    this.state.foods.push({
      id: `food_${Math.random()}`,
      x: x ?? Math.random() * WORLD_SIZE,
      y: y ?? Math.random() * WORLD_SIZE,
      color: color ?? randomColor(),
      value: value ?? Math.floor(Math.random() * 5) + 1,
      size: value ? Math.sqrt(value) * 3 : Math.random() * 3 + 3
    });
  }

  private update(dt: number) {
    // Update bots
    this.state.snakes.filter(s => !s.isPlayer && !s.dead).forEach(bot => {
      this.updateBotAI(bot, dt);
    });

    // Update all snakes
    this.state.snakes.forEach(snake => {
      if (snake.dead) return;

      snake.angle = lerpAngle(snake.angle, snake.targetAngle, snake.turnSpeed * dt);

      if (snake.isBoosting && snake.score > 20) {
        snake.speed = snake.boostSpeed;
        snake.score -= 0.3 * dt;
        snake.targetLength = Math.max(40, Math.floor(snake.score));
        
        if (Math.random() < 0.2 * dt) {
          const tail = snake.segments[snake.segments.length - 1];
          this.addFood(tail.x, tail.y, 1, snake.color);
        }
      } else {
        snake.speed = snake.baseSpeed;
        snake.isBoosting = false;
      }

      const head = { ...snake.segments[0] };
      head.x += Math.cos(snake.angle) * snake.speed * dt;
      head.y += Math.sin(snake.angle) * snake.speed * dt;

      if (head.x < 0 || head.x > WORLD_SIZE || head.y < 0 || head.y > WORLD_SIZE) {
        snake.dead = true;
        this.handleSnakeDeath(snake);
        return;
      }

      snake.segments.unshift(head);

      while (snake.segments.length > snake.targetLength) {
        snake.segments.pop();
      }

      snake.radius = BASE_SNAKE_RADIUS + Math.sqrt(snake.score) * 0.4;
    });

    // Collisions
    for (let i = 0; i < this.state.snakes.length; i++) {
      const snake1 = this.state.snakes[i];
      if (snake1.dead) continue;
      const head = snake1.segments[0];

      for (let j = 0; j < this.state.snakes.length; j++) {
        if (i === j) continue;
        const snake2 = this.state.snakes[j];
        if (snake2.dead) continue;

        for (let k = 0; k < snake2.segments.length; k += 2) {
          const segment = snake2.segments[k];
          if (distance(head, segment) < snake1.radius + snake2.radius * 0.8) {
            snake1.dead = true;
            this.handleSnakeDeath(snake1);
            if (snake1.isPlayer) {
                snake2.score += snake1.score * 0.2;
            }
            break;
          }
        }
        if (snake1.dead) break;
      }

      for (let j = this.state.foods.length - 1; j >= 0; j--) {
        const food = this.state.foods[j];
        if (distance(head, food) < snake1.radius + food.size) {
          snake1.score += food.value;
          snake1.targetLength = Math.max(40, Math.floor(snake1.score));
          this.state.foods.splice(j, 1);
        }
      }
    }

    while (this.state.foods.length < INITIAL_FOOD_COUNT) {
      this.addFood();
    }

    const aliveBots = this.state.snakes.filter(s => !s.isPlayer && !s.dead).length;
    if (aliveBots < BOT_COUNT && Math.random() < 0.02 * dt) {
      this.addBot();
    }

    this.state.snakes = this.state.snakes.filter(s => !s.dead);
  }

  private handleSnakeDeath(snake: Snake) {
    snake.segments.forEach((seg, index) => {
      if (index % 3 === 0) {
        this.addFood(
          seg.x + (Math.random() - 0.5) * 20, 
          seg.y + (Math.random() - 0.5) * 20, 
          Math.min(15, Math.max(2, snake.score / snake.segments.length * 3)),
          snake.color
        );
      }
    });
    this.io.emit('snakeDied', { x: snake.segments[0].x, y: snake.segments[0].y, color: snake.color });
  }

  private updateBotAI(bot: Snake, dt: number) {
    const head = bot.segments[0];
    bot.botStateTimer = (bot.botStateTimer || 0) - dt;
    
    let nearestThreat: Point | null = null;
    let minThreatDist = 150 + bot.radius;

    for (const other of this.state.snakes) {
      if (other.id === bot.id || other.dead) continue;
      
      for (let i = 0; i < other.segments.length; i += 4) {
        const seg = other.segments[i];
        const dist = distance(head, seg);
        if (dist < minThreatDist) {
          minThreatDist = dist;
          nearestThreat = seg;
        }
      }
    }

    if (nearestThreat) {
      bot.targetAngle = Math.atan2(head.y - nearestThreat.y, head.x - nearestThreat.x);
      bot.isBoosting = minThreatDist < 100 && bot.score > 50;
      bot.botTarget = null;
      bot.botStateTimer = 20; 
    } else {
      bot.isBoosting = false;

      if (bot.botStateTimer <= 0 || !bot.botTarget) {
        bot.botStateTimer = Math.random() * 60 + 40; 
        
        if (Math.random() < 0.8) {
          let nearestFood: Food | null = null;
          let minFoodDist = Infinity;
          
          for (let i = 0; i < this.state.foods.length; i += 3) {
            const food = this.state.foods[i];
            const dist = distance(head, food);
            if (dist < minFoodDist && dist < 800) {
              minFoodDist = dist;
              nearestFood = food;
            }
          }
          bot.botTarget = nearestFood || null;
        }
        
        if (!bot.botTarget) {
          bot.botTarget = {
            x: head.x + (Math.random() - 0.5) * 1000,
            y: head.y + (Math.random() - 0.5) * 1000
          };
        }
      }

      if (bot.botTarget) {
        bot.targetAngle = Math.atan2(bot.botTarget.y - head.y, bot.botTarget.x - head.x);
      }
    }

    const margin = 300;
    if (head.x < margin) bot.targetAngle = 0;
    else if (head.x > WORLD_SIZE - margin) bot.targetAngle = Math.PI;
    else if (head.y < margin) bot.targetAngle = Math.PI / 2;
    else if (head.y > WORLD_SIZE - margin) bot.targetAngle = -Math.PI / 2;
  }
}
