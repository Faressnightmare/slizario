/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Game } from './components/Game';
import { Play, RotateCcw, Trophy } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

type AppState = 'menu' | 'playing' | 'gameover';

export default function App() {
  const [gameState, setGameState] = useState<AppState>('menu');
  const [lastScore, setLastScore] = useState(0);
  const [highScore, setHighScore] = useState(0);
  const [gameKey, setGameKey] = useState(0);
  const [playerName, setPlayerName] = useState('');

  const handleStart = () => {
    setGameKey(prev => prev + 1);
    setGameState('playing');
  };

  const handleGameOver = (score: number) => {
    setLastScore(score);
    if (score > highScore) {
      setHighScore(score);
    }
    setGameState('gameover');
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-50 font-sans selection:bg-emerald-500/30">
      <AnimatePresence mode="wait">
        {gameState === 'menu' ? (
          <motion.div 
            key="menu"
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 1.05 }}
            className="absolute inset-0 flex items-center justify-center bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-slate-900 via-slate-950 to-black"
          >
            <div className="max-w-md w-full p-8 relative">
              <div className="absolute inset-0 bg-emerald-500/10 blur-3xl rounded-full -z-10" />
              <div className="text-center mb-12">
                <h1 className="text-6xl font-black tracking-tighter mb-4 bg-gradient-to-br from-emerald-400 to-cyan-500 bg-clip-text text-transparent drop-shadow-sm">
                  Neon Slither
                </h1>
                <p className="text-slate-400 text-lg">Eat orbs, grow longer, outsmart bots.</p>
              </div>

              <div className="mb-6">
                <input 
                  type="text" 
                  placeholder="Enter your name" 
                  value={playerName} 
                  onChange={e => setPlayerName(e.target.value)}
                  className="w-full bg-slate-900/50 border border-slate-700 rounded-2xl px-6 py-4 text-white text-lg focus:outline-none focus:border-emerald-500 transition-colors placeholder:text-slate-600"
                  maxLength={16}
                />
              </div>

              <button 
                onClick={handleStart}
                className="w-full group relative inline-flex items-center justify-center gap-3 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xl py-5 px-8 rounded-2xl transition-all hover:scale-[1.02] active:scale-[0.98] shadow-[0_0_40px_-10px_rgba(16,185,129,0.5)]"
              >
                <Play className="w-6 h-6 fill-current" />
                Play Now
              </button>
              
              <div className="mt-8 text-center text-slate-500 text-sm">
                <p>Move mouse to steer • Click to boost</p>
              </div>
            </div>
          </motion.div>
        ) : (
          <motion.div 
            key="game-container"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0"
          >
            <Game key={gameKey} playerName={playerName || 'Player'} onGameOver={handleGameOver} />
            
            <AnimatePresence>
              {gameState === 'gameover' && (
                <motion.div 
                  key="gameover"
                  initial={{ opacity: 0, backdropFilter: 'blur(0px)' }}
                  animate={{ opacity: 1, backdropFilter: 'blur(12px)' }}
                  exit={{ opacity: 0 }}
                  className="absolute inset-0 flex items-center justify-center bg-slate-950/60 z-50"
                >
                  <div className="max-w-sm w-full bg-slate-900 border border-slate-800 rounded-3xl p-8 shadow-2xl text-center relative overflow-hidden">
                    <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-rose-500 to-orange-500" />
                    
                    <h2 className="text-3xl font-bold text-white mb-2">Game Over!</h2>
                    <p className="text-slate-400 mb-8">You crashed into another snake.</p>
                    
                    <div className="grid grid-cols-2 gap-4 mb-8">
                      <div className="bg-slate-800/50 rounded-2xl p-4 border border-slate-700/50">
                        <p className="text-slate-500 text-xs font-bold uppercase tracking-wider mb-1">Score</p>
                        <p className="text-3xl font-mono font-bold text-white">{lastScore}</p>
                      </div>
                      <div className="bg-slate-800/50 rounded-2xl p-4 border border-slate-700/50">
                        <p className="text-slate-500 text-xs font-bold uppercase tracking-wider mb-1 flex items-center justify-center gap-1">
                          <Trophy className="w-3 h-3 text-amber-400" /> Best
                        </p>
                        <p className="text-3xl font-mono font-bold text-amber-400">{highScore}</p>
                      </div>
                    </div>

                    <button 
                      onClick={handleStart}
                      className="w-full inline-flex items-center justify-center gap-2 bg-white hover:bg-slate-100 text-slate-900 font-bold text-lg py-4 px-8 rounded-xl transition-all hover:scale-[1.02] active:scale-[0.98]"
                    >
                      <RotateCcw className="w-5 h-5" />
                      Play Again
                    </button>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
