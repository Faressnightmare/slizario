import { GameState, Point, Particle } from '../game/types';

const WORLD_SIZE = 3000;

export class GameRenderer {
  private canvas: HTMLCanvasElement;
  private ctx: CanvasRenderingContext2D;
  public camera: Point = { x: WORLD_SIZE / 2, y: WORLD_SIZE / 2 };
  public zoom: number = 1;
  public particles: Particle[] = [];
  private lastTime: number = Date.now();

  constructor(canvas: HTMLCanvasElement) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d')!;
  }

  public addParticles(x: number, y: number, color: string, count: number) {
    for (let i = 0; i < count; i++) {
      const angle = Math.random() * Math.PI * 2;
      const speed = Math.random() * 5 + 2;
      this.particles.push({
        x, y,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed,
        life: 1,
        maxLife: Math.random() * 30 + 20,
        color,
        size: Math.random() * 4 + 2
      });
    }
  }

  public draw(state: GameState, playerId: string | null) {
    const now = Date.now();
    const dt = (now - this.lastTime) / (1000 / 60);
    this.lastTime = now;

    const { width, height } = this.canvas;
    const player = playerId ? state.snakes.find(s => s.id === playerId) : null;

    // Update camera smoothly
    if (player && !player.dead) {
      const targetZoom = 1.2 - Math.min(0.6, player.score / 8000);
      this.zoom += (targetZoom - this.zoom) * 0.1;
      this.camera.x += (player.segments[0].x - this.camera.x) * 0.2;
      this.camera.y += (player.segments[0].y - this.camera.y) * 0.2;
    } else {
      this.zoom += (0.5 - this.zoom) * 0.02;
      this.camera.x += Math.cos(now * 0.0001) * 2;
      this.camera.y += Math.sin(now * 0.0001) * 2;
    }

    // Clear background
    this.ctx.fillStyle = '#020617'; // slate-950
    this.ctx.fillRect(0, 0, width, height);

    this.ctx.save();
    
    // Apply camera transform
    this.ctx.translate(width / 2, height / 2);
    this.ctx.scale(this.zoom, this.zoom);
    this.ctx.translate(-this.camera.x, -this.camera.y);

    // Calculate visible area for culling (performance optimization)
    const viewLeft = this.camera.x - (width / 2) / this.zoom - 100;
    const viewRight = this.camera.x + (width / 2) / this.zoom + 100;
    const viewTop = this.camera.y - (height / 2) / this.zoom - 100;
    const viewBottom = this.camera.y + (height / 2) / this.zoom + 100;

    // Draw grid
    this.ctx.strokeStyle = '#0f172a'; // slate-900
    this.ctx.lineWidth = 2;
    const gridSize = 100;
    const startX = Math.max(0, Math.floor(viewLeft / gridSize) * gridSize);
    const startY = Math.max(0, Math.floor(viewTop / gridSize) * gridSize);
    const endX = Math.min(WORLD_SIZE, viewRight + gridSize);
    const endY = Math.min(WORLD_SIZE, viewBottom + gridSize);

    this.ctx.beginPath();
    for (let x = startX; x <= endX; x += gridSize) {
      this.ctx.moveTo(x, startY);
      this.ctx.lineTo(x, endY);
    }
    for (let y = startY; y <= endY; y += gridSize) {
      this.ctx.moveTo(startX, y);
      this.ctx.lineTo(endX, y);
    }
    this.ctx.stroke();

    // Draw world bounds
    this.ctx.strokeStyle = '#ef4444'; // red-500
    this.ctx.lineWidth = 10;
    this.ctx.strokeRect(0, 0, WORLD_SIZE, WORLD_SIZE);

    // Draw foods (with culling)
    state.foods.forEach(food => {
      if (food.x < viewLeft || food.x > viewRight || food.y < viewTop || food.y > viewBottom) return;
      
      this.ctx.beginPath();
      this.ctx.arc(food.x, food.y, food.size, 0, Math.PI * 2);
      this.ctx.fillStyle = food.color;
      this.ctx.fill();
    });

    // Update and draw particles (with culling)
    for (let i = this.particles.length - 1; i >= 0; i--) {
      const p = this.particles[i];
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      p.life += dt;
      
      if (p.life >= p.maxLife) {
        this.particles.splice(i, 1);
        continue;
      }

      if (p.x < viewLeft || p.x > viewRight || p.y < viewTop || p.y > viewBottom) continue;

      this.ctx.globalAlpha = Math.max(0, 1 - (p.life / p.maxLife));
      this.ctx.beginPath();
      this.ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
      this.ctx.fillStyle = p.color;
      this.ctx.fill();
    }
    this.ctx.globalAlpha = 1;

    // Draw snakes (from tail to head)
    state.snakes.forEach(snake => {
      if (snake.dead) return;

      // Quick bounding box check for the whole snake
      let inView = false;
      for (const seg of snake.segments) {
        if (seg.x >= viewLeft && seg.x <= viewRight && seg.y >= viewTop && seg.y <= viewBottom) {
          inView = true;
          break;
        }
      }
      if (!inView) return;

      // Draw body
      for (let i = snake.segments.length - 1; i >= 0; i--) {
        const seg = snake.segments[i];
        if (seg.x < viewLeft || seg.x > viewRight || seg.y < viewTop || seg.y > viewBottom) continue;

        const isHead = i === 0;
        
        this.ctx.beginPath();
        this.ctx.arc(seg.x, seg.y, snake.radius * (isHead ? 1.1 : 1), 0, Math.PI * 2);
        
        if (snake.isBoosting && i % 2 === 0) {
          this.ctx.fillStyle = '#ffffff';
        } else {
          this.ctx.fillStyle = snake.color;
        }
        
        this.ctx.fill();

        // Draw eyes on head
        if (isHead) {
          const eyeOffset = snake.radius * 0.5;
          const eyeRadius = snake.radius * 0.3;
          
          this.ctx.fillStyle = '#ffffff';
          
          // Left eye
          this.ctx.beginPath();
          this.ctx.arc(
            seg.x + Math.cos(snake.angle - Math.PI/4) * eyeOffset,
            seg.y + Math.sin(snake.angle - Math.PI/4) * eyeOffset,
            eyeRadius, 0, Math.PI * 2
          );
          this.ctx.fill();

          // Right eye
          this.ctx.beginPath();
          this.ctx.arc(
            seg.x + Math.cos(snake.angle + Math.PI/4) * eyeOffset,
            seg.y + Math.sin(snake.angle + Math.PI/4) * eyeOffset,
            eyeRadius, 0, Math.PI * 2
          );
          this.ctx.fill();

          // Pupils
          this.ctx.fillStyle = '#000000';
          this.ctx.beginPath();
          this.ctx.arc(
            seg.x + Math.cos(snake.angle - Math.PI/4) * eyeOffset + Math.cos(snake.angle) * eyeRadius * 0.5,
            seg.y + Math.sin(snake.angle - Math.PI/4) * eyeOffset + Math.sin(snake.angle) * eyeRadius * 0.5,
            eyeRadius * 0.5, 0, Math.PI * 2
          );
          this.ctx.fill();

          this.ctx.beginPath();
          this.ctx.arc(
            seg.x + Math.cos(snake.angle + Math.PI/4) * eyeOffset + Math.cos(snake.angle) * eyeRadius * 0.5,
            seg.y + Math.sin(snake.angle + Math.PI/4) * eyeOffset + Math.sin(snake.angle) * eyeRadius * 0.5,
            eyeRadius * 0.5, 0, Math.PI * 2
          );
          this.ctx.fill();
        }
      }

      // Draw name
      const head = snake.segments[0];
      if (head.x >= viewLeft && head.x <= viewRight && head.y >= viewTop && head.y <= viewBottom) {
        this.ctx.fillStyle = 'rgba(255, 255, 255, 0.8)';
        this.ctx.font = `bold ${Math.max(12, snake.radius)}px Inter, sans-serif`;
        this.ctx.textAlign = 'center';
        this.ctx.fillText(snake.name, head.x, head.y - snake.radius - 10);
      }
    });

    this.ctx.restore();

    // --- Draw Minimap ---
    const minimapSize = 150;
    const margin = 20;
    const minimapX = width - minimapSize - margin;
    const minimapY = height - minimapSize - margin;

    // Minimap background
    this.ctx.fillStyle = 'rgba(15, 23, 42, 0.7)'; // slate-900 with opacity
    this.ctx.strokeStyle = '#334155'; // slate-700
    this.ctx.lineWidth = 2;
    this.ctx.fillRect(minimapX, minimapY, minimapSize, minimapSize);
    this.ctx.strokeRect(minimapX, minimapY, minimapSize, minimapSize);

    const scale = minimapSize / WORLD_SIZE;

    // Draw entities on minimap
    state.snakes.forEach(snake => {
      if (snake.dead || snake.segments.length === 0) return;
      const head = snake.segments[0];
      const isMe = snake.id === playerId;
      
      this.ctx.fillStyle = isMe ? '#10b981' : '#ef4444'; // emerald-500 for me, red-500 for others
      this.ctx.beginPath();
      this.ctx.arc(
        minimapX + head.x * scale,
        minimapY + head.y * scale,
        isMe ? 4 : 2,
        0, Math.PI * 2
      );
      this.ctx.fill();
    });

    // Draw camera viewport on minimap
    this.ctx.strokeStyle = 'rgba(255, 255, 255, 0.3)';
    this.ctx.lineWidth = 1;
    const viewW = (width / this.zoom) * scale;
    const viewH = (height / this.zoom) * scale;
    const viewX = minimapX + (this.camera.x * scale) - (viewW / 2);
    const viewY = minimapY + (this.camera.y * scale) - (viewH / 2);
    this.ctx.strokeRect(viewX, viewY, viewW, viewH);
  }
}
